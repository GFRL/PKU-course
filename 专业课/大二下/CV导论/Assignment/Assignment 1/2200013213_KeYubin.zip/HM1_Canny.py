import numpy as np
from HM1_Convolve import Gaussian_filter, Sobel_filter_x, Sobel_filter_y
from utils import read_img, write_img

def compute_gradient_magnitude_direction(x_grad, y_grad):
    """
        The function you need to implement for Q2 a).
        Inputs:
            x_grad: array(float) 
            y_grad: array(float)
        Outputs:
            magnitude_grad: array(float)
            direction_grad: array(float) you may keep the angle of the gradient at each pixel
    """
    magnitude_grad = np.sqrt(x_grad**2 + y_grad**2)
    direction_grad = np.arctan2(y_grad, x_grad)
    return magnitude_grad, direction_grad 


def non_maximal_suppressor(grad_mag, grad_dir):
    """
        The function you need to implement for Q2 b).
        Inputs:
            grad_mag: array(float) 
            grad_dir: array(float)
        Outputs:
            output: array(float)
    """   
    row, col = grad_mag.shape
    grad_dir=(22.5+(grad_dir*180/np.pi))%180#加了22.5度，然后取模180度
    offsetx=np.array([0,1,1,1])
    offsety=np.array([1,1,0,-1])
    id=np.floor(grad_dir/45).astype(int)
    offset1x=offsetx[id]
    offset1y=offsety[id]

    row_neighbor, col_neighbor = np.meshgrid(np.arange(row), np.arange(col), indexing='ij')
    row_neighbor_msg=grad_mag[(row_neighbor+offset1x).clip(0,row-1),(col_neighbor+offset1y).clip(0,col-1)]
    row_neighbor_msg1=grad_mag[(row_neighbor-offset1x).clip(0,row-1),(col_neighbor-offset1y).clip(0,col-1)]
    grad_mag[grad_mag<=row_neighbor_msg]=0
    grad_mag[grad_mag<=row_neighbor_msg1]=0
    NMS_output=grad_mag
    return NMS_output 
        
def hysteresis_thresholding(img) :
    """
        The function you need to implement for Q2 c).
        Inputs:
            img: array(float) 
        Outputs:
            output: array(float)
    """


    #you can adjust the parameters to fit your own implementation 
    low_ratio = 0.10
    high_ratio = 0.30
    
    row, col = img.shape
    output=np.zeros((row,col))
    
    for i in range(row):
        for j in range(col):
            if img[i,j]>high_ratio:
                output[i,j]=1
    #开始蔓延
    while True:
        flag=False
        for i in range(row):
            for j in range(col):
                if output[i,j]==1:
                    for x in range(-1,2):
                        for y in range(-1,2):
                            if i+x>=0 and i+x<row and j+y>=0 and j+y<col:
                                if img[i+x,j+y]>low_ratio and output[i+x,j+y]==0:
                                    output[i+x,j+y]=1
                                    flag=True
        if not flag:
            break

    return output 


if __name__=="__main__":

    #Load the input images
    input_img = read_img("Lenna.png")/255

    #Apply gaussian blurring
    blur_img = Gaussian_filter(input_img)

    x_grad = Sobel_filter_x(blur_img)
    y_grad = Sobel_filter_y(blur_img)

    #Compute the magnitude and the direction of gradient
    magnitude_grad, direction_grad = compute_gradient_magnitude_direction(x_grad, y_grad)

    #NMS
    NMS_output = non_maximal_suppressor(magnitude_grad, direction_grad)

    #Edge linking with hysteresis
    output_img = hysteresis_thresholding(NMS_output)
    
    write_img("result/HM1_Canny_result.png", output_img*255)
