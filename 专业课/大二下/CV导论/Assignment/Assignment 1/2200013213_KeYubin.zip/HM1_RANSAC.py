import numpy as np
from utils import draw_save_plane_with_points

if __name__ == "__main__":


    # load data, total 130 points inlcuding 100 inliers and 30 outliers
    noise_points = np.loadtxt("HM1_ransac_points.txt")


    #RANSAC
    # we recommend you to formulate the palnace function as:  A*x+B*y+C*z+D=0    
    #每次需要三个点
    P_truth=0.999
    p_inliner=100/130
    k=3
    sample_time =int(np.ceil(np.log(1-P_truth)/np.log(1-np.power(p_inliner,k)))) #more than 99.9% probability at least one hypothesis does not contain any outliers 
    distance_threshold = 0.05
    # sample points group
    sample_id=np.random.randint(130,size=(int(sample_time),3))

    sample_plane_arg=np.zeros((int(sample_time),4))

    x1 = noise_points[sample_id[:, 0], 0]
    y1 = noise_points[sample_id[:, 0], 1]
    z1 = noise_points[sample_id[:, 0], 2]
    x2 = noise_points[sample_id[:, 1], 0]
    y2 = noise_points[sample_id[:, 1], 1]
    z2 = noise_points[sample_id[:, 1], 2]
    x3 = noise_points[sample_id[:, 2], 0]
    y3 = noise_points[sample_id[:, 2], 1]
    z3 = noise_points[sample_id[:, 2], 2]
    # estimate the plane with sampled points group
    #A(x1-x2)+B(y1-y2)+C(z1-z2)=0
    #A(x1-x3)+B(y1-y3)+C(z1-z3)=0
    #A((x1-x2)(z1-z3)-(x1-x3)(z1-z2))+B((y1-y2)(z1-z3)-(y1-y3)(z1-z2))=0
    #
    A=((y1-y2)*(z1-z3)-(y1-y3)*(z1-z2))
    B=-((x1-x2)*(z1-z3)-(x1-x3)*(z1-z2))
    C=((x2-x1)*(y3-y1)-(x3-x1)*(y2-y1))
    D=-(A*x1+B*y1+C*z1)
    #得堆起来

    A=np.repeat(A,130).reshape(sample_time,-1)
    B=np.repeat(B,130).reshape(sample_time,-1)
    C=np.repeat(C,130).reshape(sample_time,-1)
    D=np.repeat(D,130).reshape(sample_time,-1)
    
    #evaluate inliers (with point-to-plance distance < distance_threshold)
    x=noise_points[:,0]
    y=noise_points[:,1]
    z=noise_points[:,2]
    distance=np.abs(A*x+B*y+C*z+D)/np.sqrt(A**2+B**2+C**2)
    inliers=(distance<distance_threshold)
    inliers_num=np.sum(inliers,axis=1)
    plane_best=np.argsort(inliers_num)[-1]

    # minimize the sum of squared perpendicular distances of all inliers with least-squared method 
    best_plane_inlier_points=noise_points[np.where(distance[plane_best]<distance_threshold)]

    x=best_plane_inlier_points[:,0]
    y=best_plane_inlier_points[:,1]
    z=best_plane_inlier_points[:,2]
    w=np.ones_like(x)

    U,D,V_T=np.linalg.svd(np.stack([x,y,z,w],axis=1))
    pf=V_T[-1,:]
    # draw the estimated plane with points and save the results 
    # check the utils.py for more details
    # pf: [A,B,C,D] contains the parameters of palnace function  A*x+B*y+C*z+D=0  
    draw_save_plane_with_points(pf, noise_points,"result/HM1_RANSAC_fig.png") 
    np.savetxt("result/HM1_RANSAC_plane.txt", pf)

