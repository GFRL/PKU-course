from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.utils.data
import torch.nn.functional as F


class PointNetfeat(nn.Module):
    '''
        The feature extractor in PointNet, corresponding to the left MLP in the pipeline figure.
        Args:
        d: the dimension of the global feature, default is 1024.
        segmentation: whether to perform segmentation, default is True.
    '''
    def __init__(self, segmentation = False, d=1024):
        super(PointNetfeat, self).__init__()
        ## ------------------- TODO ------------------- ##
        ## Define the layers in the feature extractor. ##
        # 3->64->128->d
        #input: (B,3，N)
        self.d=d
        
        self.segmentation=segmentation
        self.sequential1=nn.Sequential(
            nn.Conv1d(3,64,1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
        )#output:(B,64,N)
        self.sequential2=nn.Sequential(
            nn.Conv1d(64,128,1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
        )#output: (B, 128, N)
        self.sequential3=nn.Sequential(
            nn.Conv1d(128,d,1),
            nn.BatchNorm1d(d),
            nn.ReLU(),
        )#output: (B, d, N)
        # self.pool=nn.MaxPool1d(kernel_size=)#output: (B, 1, d)
        ## ------------------------------------------- ##

    def forward(self, x):
        '''
            If segmentation == True
                return the concatenated global feature and local feature. # (B, d+64, N)
            If segmentation == False
                return the global feature, and the per point feature for cruciality visualization in question b). # (B, d), (B, N, d)
            Here, B is the batch size, N is the number of points, d is the dimension of the global feature.
        '''
        ## ------------------- TODO ------------------- ##
        ## Implement the forward pass.                 ##
        ## ------------------------------------------- ##
        x=self.sequential1(x)
        n_points=x.shape[2]
        local_feature=x#output: (B, 64,N)
        x=self.sequential2(x)
        x=self.sequential3(x)#output: (B, d, N)
        global_feature=x.permute(0,2,1)##output: (B, N, d)
        x,_=torch.max(x,dim=2)##output: (B, d)
        
        #x=x.permute(0,2,1)#output: (B, d, 1)
        if self.segmentation:
            x=x.reshape(x.shape[0],x.shape[1],1)#output: (B, d, 1)
            x=x.repeat(1,1,n_points)#output: (B, d, N)
            #print("local_feature",local_feature.shape,"x",x.shape)
            return torch.cat((local_feature,x),dim=1)#output: (B, d+64, N)
        else:
            return x,global_feature#output: (B, d), (B, N, d)
    

class PointNetCls1024D(nn.Module):
    '''
        The classifier in PointNet, corresponding to the middle right MLP in the pipeline figure.
        Args:
        k: the number of classes, default is 2.
    '''
    def __init__(self, k=2):
        super(PointNetCls1024D, self).__init__()
        ## ------------------- TODO ------------------- ##
        ## Define the layers in the classifier.        ##
        ## ------------------------------------------- ##
        self.feat=PointNetfeat(segmentation=False,d=1024)
        self.mlp01=nn.Sequential(
            nn.Linear(1024,512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
        )
        self.mlp02=nn.Sequential(
            nn.Linear(512,256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
        )
        self.mlp03=nn.Linear(256,k)
            
    def forward(self, x):
        '''
            return the log softmax of the classification result and the per point feature for cruciality visualization in question b). # (B, k), (B, N, d=1024)
        '''
        ## ------------------- TODO ------------------- ##
        ## Implement the forward pass.                 ##
        ## ------------------------------------------- ##
        #Input: (B,3,N)
        print(x.shape)
        x=x.permute(0,2,1)#output: (B, N, 3)
        x,global_feature=self.feat(x)#output: (B, d), (B, N, d)d=1024
        x=self.mlp01(x)#output: (B, 512)
        x=self.mlp02(x)#output: (B, 256)
        x=self.mlp03(x)#output: (B, k)
        return F.log_softmax(x,dim=1),global_feature#output: (B, k), (B, N, d=1024)
class PointNetCls256D(nn.Module):
    '''
        The classifier in PointNet, corresponding to the upper right MLP in the pipeline figure.
        Args:
        k: the number of classes, default is 2.
    '''
    def __init__(self, k=2 ):
        super(PointNetCls256D, self).__init__()
        ## ------------------- TODO ------------------- ##
        ## Define the layers in the classifier.        ##
        ## ------------------------------------------- ##
        self.feat=PointNetfeat(segmentation=False,d=256)
        self.mlp01=nn.Sequential(
            nn.Linear(256,128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
        )
        self.mlp02=nn.Linear(128,k)
    def forward(self, x):
        '''
            return the log softmax of the classification result and the per point feature for cruciality visualization in question b). # (B, k), (B, N, d=256)
        '''
        ## ------------------- TODO ------------------- ##
        ## Implement the forward pass.                 ##
        ## ------------------------------------------- ##
        x=x.permute(0,2,1)#output: (B, N, 3)    
        x,global_feature=self.feat(x)#output: (B, d), (B, N, d)d=256
        x=self.mlp01(x)#output: (B, 128)
        x=self.mlp02(x)#output: (B, k)
        return F.log_softmax(x,dim=1),global_feature#output: (B, k), (B, N, d=256)

class PointNetSeg(nn.Module):
    '''
        The segmentation head in PointNet, corresponding to the lower right MLP in the pipeline figure.
        Args:
        k: the number of classes, default is 2.
    '''
    def __init__(self, k = 2):
        super(PointNetSeg, self).__init__()
        ## ------------------- TODO ------------------- ##
        ## Define the layers in the segmentation head. ##
        ## ------------------------------------------- ##
        self.seg=PointNetfeat(segmentation=True,d=1024)
        self.mlp01=nn.Sequential(
            nn.Conv1d(1088,512,1),
            nn.BatchNorm1d(512),
            nn.ReLU(),
        )
        self.mlp02=nn.Sequential(
            nn.Conv1d(512,256,1),
            nn.BatchNorm1d(256),
            nn.ReLU(),
        )
        self.mlp03=nn.Sequential(
            nn.Conv1d(256,128,1),
            nn.BatchNorm1d(128),
            nn.ReLU(),
        )
        self.mlp04=nn.Linear(128,k)
    def forward(self, x):
        '''
            Input:
                x: (B,N,3)
                先经过PointNetfeat得到(B, d+64, N)
                x: the concatenated global feature and local feature. # (B, d+64, N)
            Output:
                the log softmax of the segmentation result. # (B, N, k)
        '''
        ## ------------------- TODO ------------------- ##
        ## Implement the forward pass.                 ##
        ## ------------------------------------------- ##
        x=x.permute(0,2,1)
        x=self.seg(x)#传进去的是(B,3,N)，输出是(B, d+64,N)d=1024
        x=self.mlp01(x)#output: (B, 512, N)
        x=self.mlp02(x)#output: (B, 256, N)
        x=self.mlp03(x)#output: (B, 128, N)
        x=x.permute(0,2,1)#output: (B, N, 128)
        x=self.mlp04(x)#output: (B, N, k)
        return F.log_softmax(x,dim=2)